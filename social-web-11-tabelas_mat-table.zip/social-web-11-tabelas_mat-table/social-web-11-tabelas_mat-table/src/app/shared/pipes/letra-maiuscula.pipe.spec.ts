import { LetraMaiusculaPipe } from './letra-maiuscula.pipe';

describe('LetraMaiusculaPipe', () => {
  it('create an instance', () => {
    const pipe = new LetraMaiusculaPipe();
    expect(pipe).toBeTruthy();
  });
});
